function Book(title, author, pages){
	this.title = title;
	this.author = author;
	this.pages = pages;
}
